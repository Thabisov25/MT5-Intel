"""The mt5-intel family rules, wrapped as a freqtrade strategy for offline backtesting.

The point of this adapter is that **the signal logic is not ported - it is imported**. The
family functions from `mt5_intel.research.strategies` are the same objects the research
tables and the live cards are graded by, so a freqtrade backtest here cannot drift from the
replays: same bars, same rules, same stops. What freqtrade brings is the engine around them -
candle-accurate fills, the trade lifecycle, and hyperopt.

What is approximated, stated plainly:

* **Entry price** is the next candle's open (freqtrade's default), which is what the research
  rules assume (D-012).
* **Stop and target** are enforced by `custom_stoploss` / `custom_exit` as absolute prices
  derived from the signal bar's stop-pips and R-multiple, exactly as the mt5-intel sizing
  does - but freqtrade marks exits at the candle's own price, where the live engine places a
  broker-side stop order. On a gappy market those differ by the gap.
* **Spread** is not charged by freqtrade (the exported candles carry no cost model); the
  research pages charge it in R via `cost_in_r`. Read the expectancy numbers as pre-spread.

Bars arrive as UTC (the exporter resolved the broker clock offset before writing), so
`utc_offset_s=0` here is a fact about the file, not an assumption about the market.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
from freqtrade.persistence import Trade
from freqtrade.strategy import DecimalParameter, IStrategy, IntParameter

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from mt5_intel.research.backtest import Bars  # noqa: E402
from mt5_intel.research.strategies import carry_trend, sweep_and_reclaim  # noqa: E402


def _digits_for(pair: str) -> int:
    """Quote precision the way its market quotes it: JPY 3, gold 2, everything else 5."""
    base, _, quote = pair.partition("/")
    if quote == "JPY":
        return 3
    if base == "XAU":
        return 2
    return 5


def dataframe_to_bars(df: pd.DataFrame, pair: str) -> Bars:
    """The analysed frame back to the shape every family rule has always taken.

    `date` comes in as millisecond stamps (the handlers' format) and `Bars.time` counts
    UTC seconds; `spread_points` is carried through the export so the stops see the real
    spread distribution even though freqtrade itself charges no cost.
    """
    digits = _digits_for(pair)
    point = 10.0 ** (-digits)
    spread = (
        df["spread_points"].to_numpy(dtype=np.int32)
        if "spread_points" in df.columns
        else np.zeros(len(df), dtype=np.int32)
    )
    return Bars(
        time=(df["date"].astype("int64") // 1000).to_numpy(),
        open_=df["open"].to_numpy(dtype="float64"),
        high=df["high"].to_numpy(dtype="float64"),
        low=df["low"].to_numpy(dtype="float64"),
        close=df["close"].to_numpy(dtype="float64"),
        spread_points=spread,
        point=point,
        digits=digits,
        utc_offset_s=0,  # the exporter already put these stamps on UTC
    )


class MT5FamilyBase(IStrategy):
    """Shared plumbing: family signals in, freqtrade's trade lifecycle out.

    Subclasses set `family_fn` and declare their own hyperopt space. The interface version,
    the empty exit table and the R-multiple management live here once.
    """

    INTERFACE_VERSION = 3
    timeframe = "1h"
    # The families signal both directions, but the pilot runs on spot data - the only
    # freqtrade-supported exchange whose markets contain these FX pairs (kraken) offers no
    # futures or margin mode inside freqtrade - so the short side is ignored by the engine
    # and the research replays remain its authority. Everything else (stops, targets,
    # hyperopt) is symmetric between the sides, so what is measured here transfers.
    can_short = False
    # ROI and the static stoploss are inert: the real stop is pinned per trade by
    # custom_stoploss at the family's own stop distance, and the target is the family's own
    # R-multiple. Freqtrade needs *some* stoploss value; -0.99 is the documented "managed
    # entirely by custom_stoploss" idiom.
    minimal_roi = {"0": -100.0}
    stoploss = -0.99
    use_custom_stoploss = True
    trailing_stop = False
    process_only_new_candles = True

    family_fn = None  # set by the subclass

    def populate_indicators(self, df: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        bars = dataframe_to_bars(df, metadata["pair"])
        sig, side, stop_pips, tp_r = self.family_fn(bars, **self.family_params())
        df["enter_long"] = 0
        df["enter_short"] = 0
        df["stop_ratio"] = 0.0
        df["tp_r"] = 2.0
        if sig.size:
            # Entry is the next bar's open; the stop distance is expressed as a ratio of the
            # signal bar's close so the absolute stop can be rebuilt from the trade's own
            # entry price later, the way the sizing does it live.
            ratio = stop_pips * bars.pip() / np.maximum(bars.close[sig], 1e-12)
            long_rows = sig[side > 0]
            short_rows = sig[side < 0]
            df.iloc[long_rows, df.columns.get_loc("enter_long")] = 1
            df.iloc[short_rows, df.columns.get_loc("enter_short")] = 1
            df.iloc[sig, df.columns.get_loc("stop_ratio")] = ratio
            df.iloc[sig, df.columns.get_loc("tp_r")] = tp_r
        return df

    def populate_entry_trend(self, df: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        return df

    def populate_exit_trend(self, df: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        return df  # exits are the stop and the R-multiple target, managed per trade

    def family_params(self) -> dict:
        return {}

    def _signal_row(self, trade: Trade, current_time) -> pd.DataFrame | None:
        """The analysed row the entry was signalled on - the bar before the entry bar."""
        df, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        if df is None or df.empty:
            return None
        entries = df[(df["enter_long"] == 1) | (df["enter_short"] == 1)]
        prior = entries[entries["date"] < trade.open_date]
        return prior.iloc[-1] if len(prior) else None

    def custom_stoploss(self, trade: Trade, current_time, current_rate, after_fill, **kwargs) -> float:
        """Pin the family's stop: absolute distance from entry, expressed the way freqtrade
        wants it - a ratio from the *current* rate. Freqtrade never loosens this, so the stop
        only ever tracks the price, exactly like the broker-side stop it stands in for."""
        row = self._signal_row(trade, current_time)
        if row is None or row["stop_ratio"] <= 0:
            return 0.001  # nothing to pin from; keep the inert floor rather than guess
        stop_ratio = float(row["stop_ratio"])
        if trade.is_short:
            stop_price = trade.open_rate * (1 + stop_ratio)
            distance = (stop_price - current_rate) / current_rate
        else:
            stop_price = trade.open_rate * (1 - stop_ratio)
            distance = (current_rate - stop_price) / current_rate
        return max(float(distance), 0.001)

    def custom_exit(self, trade: Trade, current_time, current_rate, current_profit, **kwargs) -> str | None:
        """The family's planned target: entry +/- tp_r * stop distance, in R."""
        row = self._signal_row(trade, current_time)
        if row is None or row["stop_ratio"] <= 0:
            return None
        stop_ratio = float(row["stop_ratio"])
        tp_r = float(row["tp_r"])
        if trade.is_short:
            target = trade.open_rate * (1 - tp_r * stop_ratio)
            hit = current_rate <= target
        else:
            target = trade.open_rate * (1 + tp_r * stop_ratio)
            hit = current_rate >= target
        return "target_r" if hit else None


class SweepReclaimFT(MT5FamilyBase):
    """Sweep of a confirmed swing level then reclaim close back inside (H-001).

    The hyperopt space mirrors the research sweep: the swing lookback, the "swept enough"
    ATR multiple (0.05/0.15 were the research values) and the reclaim window are the
    parameters the recorded trials varied.
    """

    family_fn = staticmethod(sweep_and_reclaim)

    k = IntParameter(3, 8, default=5, space="buy", optimize=True)
    atr_mult = DecimalParameter(0.05, 0.40, default=0.05, decimals=2, space="buy", optimize=True)
    confirm_bars = IntParameter(1, 3, default=1, space="buy", optimize=True)

    def family_params(self) -> dict:
        return {"k": int(self.k.value), "atr_mult": float(self.atr_mult.value), "confirm_bars": int(self.confirm_bars.value)}


class CarryTrendFT(MT5FamilyBase):
    """Carry-gated trend (H-007): policy-rate spread agrees with close-vs-MA trend, else flat.

    `ma_days` is expressed in bars here (the family counts bars, not days), so the default
    200 matches the live rule's MA(200) on H1. The policy-rate table is the same one the
    live card reads - it is imported, not reimplemented.
    """

    family_fn = staticmethod(carry_trend)

    ma_days = IntParameter(100, 400, default=200, space="buy", optimize=True)
    stop_atr = DecimalParameter(2.0, 8.0, default=4.0, decimals=1, space="buy", optimize=True)

    def family_params(self) -> dict:
        return {"ma_days": int(self.ma_days.value), "stop_atr": float(self.stop_atr.value)}
